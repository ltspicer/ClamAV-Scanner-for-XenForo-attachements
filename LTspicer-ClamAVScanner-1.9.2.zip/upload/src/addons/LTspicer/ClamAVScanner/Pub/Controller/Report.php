<?php

namespace LTspicer\ClamAVScanner\Pub\Controller;

class Report extends \XF\Pub\Controller\AbstractController
{
	public function actionRetry(\XF\Mvc\ParameterBag $params)
	{
		$this->assertPostOnly();
		$visitor = \XF::visitor();
		if (!$visitor->user_id || !$visitor->hasPermission('general', 'viewClamAvScanReport'))
		{
			return $this->noPermission();
		}

		$id = (int)$params->attachment_id;
		$scan = $this->app()->db()->fetchRow(
			'
				SELECT s.scan_state, d.user_id, a.unassociated
				FROM xf_ltspicer_clamav_scan AS s
				INNER JOIN xf_attachment AS a ON (a.attachment_id = s.attachment_id)
				INNER JOIN xf_attachment_data AS d ON (d.data_id = a.data_id)
				WHERE s.attachment_id = ?
			',
			$id
		);
		if (!$scan || (int)$scan['user_id'] !== (int)$visitor->user_id
			|| $scan['scan_state'] !== 'error' || $scan['unassociated'])
		{
			return $this->notFound();
		}

		$updated = $this->app()->db()->update(
			'xf_ltspicer_clamav_scan',
			[
				'scan_state' => 'pending',
				'scan_date' => 0,
				'detection' => null,
				'error_message' => null
			],
			'attachment_id = ? AND scan_state = ?',
			[$id, 'error']
		);
		if (!$updated)
		{
			return $this->noPermission();
		}

		$this->app()->jobManager()->enqueueUnique(
			'ltspicerClamAvScan' . $id,
			\LTspicer\ClamAVScanner\Job\ScanAttachment::class,
			['attachment_id' => $id],
			false
		);

		return $this->redirect($this->buildLink('clamav-report'), \XF::phrase('ltspicer_clamav_retry_queued'));
	}


	public function actionForget(\XF\Mvc\ParameterBag $params)
	{
		$this->assertPostOnly();
		$visitor = \XF::visitor();
		if (!$visitor->user_id || !$visitor->hasPermission('general', 'viewClamAvScanReport'))
		{
			return $this->noPermission();
		}

		$id = (int)$params->attachment_id;
		$scan = $this->app()->db()->fetchRow(
			'
				SELECT s.scan_state, d.user_id
				FROM xf_ltspicer_clamav_scan AS s
				INNER JOIN xf_attachment AS a ON (a.attachment_id = s.attachment_id)
				INNER JOIN xf_attachment_data AS d ON (d.data_id = a.data_id)
				WHERE s.attachment_id = ?
			',
			$id
		);
		if (!$scan || (int)$scan['user_id'] !== (int)$visitor->user_id || $scan['scan_state'] !== 'clean')
		{
			return $this->notFound();
		}

		$this->app()->db()->delete(
			'xf_ltspicer_clamav_scan',
			'attachment_id = ? AND scan_state = ?',
			[$id, 'clean']
		);

		return $this->redirect($this->buildLink('clamav-report'), \XF::phrase('ltspicer_clamav_report_entry_removed'));
	}


	public function actionIndex()
	{
		$visitor = \XF::visitor();
		if (!$visitor->user_id || !$visitor->hasPermission('general', 'viewClamAvScanReport'))
		{
			return $this->noPermission();
		}

		$scans = $this->app()->db()->fetchAll(
			'
				SELECT s.*, a.data_id, d.filename, d.file_size, d.upload_date
				FROM xf_ltspicer_clamav_scan AS s
				INNER JOIN xf_attachment AS a ON (a.attachment_id = s.attachment_id)
				INNER JOIN xf_attachment_data AS d ON (d.data_id = a.data_id)
				WHERE d.user_id = ?
				ORDER BY d.upload_date DESC, s.attachment_id DESC
				LIMIT 200
			',
			[$visitor->user_id]
		);

		return $this->view('', 'ltspicer_clamav_account_report', [
			'scans' => $scans,
			'pageSelected' => 'clamav_scan_report'
		]);
	}
}
