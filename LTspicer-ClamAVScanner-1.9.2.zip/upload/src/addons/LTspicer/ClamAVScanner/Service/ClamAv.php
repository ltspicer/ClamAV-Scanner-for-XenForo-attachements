<?php

namespace LTspicer\ClamAVScanner\Service;

class ClamAv
{
	protected $app;
	protected $config;

	public function __construct(\XF\App $app, array $options = [])
	{
		$this->app = $app;
		$config = $app->config('clamavScanner') ?: [];
		$acpOptions = $app->options();
		$this->config = array_merge($config, [
			'socket' => $acpOptions->ltspicerClamAvSocket ?: ($config['socket'] ?? ''),
			'timeout' => $acpOptions->ltspicerClamAvTimeout ?: ($config['timeout'] ?? 30),
			'excluded_extensions' => $this->parseList($acpOptions->ltspicerClamAvExcludedExtensions)
				?: ($config['excluded_extensions'] ?? []),
			'excluded_user_groups' => $this->parseList($acpOptions->ltspicerClamAvExcludedUserGroups)
				?: ($config['excluded_user_groups'] ?? []),
			'excluded_forums' => $acpOptions->ltspicerClamAvExcludedForums
				?: ($config['excluded_forums'] ?? []),
			'scan_private_conversations' => (bool)$acpOptions->ltspicerClamAvScanPrivateConversations,
			'alert_user_ids' => $this->parseList($acpOptions->ltspicerClamAvAlertUserIds)
				?: ($config['alert_user_ids'] ?? [])
		]);
	}

	protected function parseList($value)
	{
		if (is_array($value))
		{
			return $value;
		}

		return preg_split('/[\s,;]+/', trim((string)$value), -1, PREG_SPLIT_NO_EMPTY) ?: [];
	}

	public function getDatabaseStatus()
	{
		$socket = isset($this->config['socket']) ? (string)$this->config['socket'] : '';
		if (!$socket)
		{
			throw new \RuntimeException('No clamd socket address is configured.');
		}

		$timeout = isset($this->config['timeout']) ? min(5, max(1, (int)$this->config['timeout'])) : 5;
		$errno = 0;
		$errstr = '';
		$stream = @stream_socket_client($socket, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT);
		if (!$stream)
		{
			throw new \RuntimeException('Cannot connect to clamd: ' . $errstr . ' (' . $errno . ').');
		}

		stream_set_timeout($stream, $timeout);
		try
		{
			$this->writeAll($stream, "zVERSION\0");
			$response = '';
			while (!feof($stream))
			{
				$part = fread($stream, 4096);
				if ($part === false)
				{
					throw new \RuntimeException('Could not read clamd database status.');
				}
				$response .= $part;
				if (strpos($response, "\0") !== false || strpos($response, "\n") !== false)
				{
					break;
				}
				$meta = stream_get_meta_data($stream);
				if (!empty($meta['timed_out']))
				{
					throw new \RuntimeException('Timed out while reading clamd database status.');
				}
			}
		}
		finally
		{
			fclose($stream);
		}

		$response = trim($response);
		if (!preg_match('/^ClamAV\s+([^\/]+)\/(\d+)\/(.+)$/', $response, $matches))
		{
			throw new \RuntimeException('Unexpected clamd VERSION response: ' . substr($response, 0, 200));
		}

		$databaseDate = strtotime(trim($matches[3]));
		if ($databaseDate === false)
		{
			throw new \RuntimeException('Could not parse the database date from clamd VERSION response.');
		}

		$ageSeconds = max(0, time() - $databaseDate);
		$warningHours = max(1, (int)$this->app->options()->ltspicerClamAvDatabaseWarningHours);

		return [
			'engineVersion' => trim($matches[1]),
			'databaseVersion' => $matches[2],
			'databaseDate' => $databaseDate,
			'ageHours' => round($ageSeconds / 3600, 1),
			'warningHours' => $warningHours,
			'isStale' => $ageSeconds > $warningHours * 3600
		];
	}

	public function scanFile($file)
	{
		if (!is_file($file) || !is_readable($file))
		{
			throw new \RuntimeException('The attachment scan file is unavailable.');
		}

		$socket = isset($this->config['socket']) ? (string)$this->config['socket'] : '';
		$timeout = isset($this->config['timeout']) ? max(1, (int)$this->config['timeout']) : 30;
		if (!$socket)
		{
			throw new \RuntimeException('Set clamavScanner.socket in src/config.php.');
		}

		$errno = 0;
		$errstr = '';
		$stream = @stream_socket_client($socket, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT);
		if (!$stream)
		{
			throw new \RuntimeException('Cannot connect to clamd: ' . $errstr . ' (' . $errno . ').');
		}

		stream_set_timeout($stream, $timeout);
		try
		{
			$this->writeAll($stream, "zINSTREAM\0");
			$input = fopen($file, 'rb');
			if (!$input)
			{
				throw new \RuntimeException('Cannot open the attachment for scanning.');
			}

			while (!feof($input))
			{
				$chunk = fread($input, 65536);
				if ($chunk === false)
				{
					fclose($input);
					throw new \RuntimeException('Cannot read the attachment for scanning.');
				}
				if ($chunk === '')
				{
					continue;
				}
				$this->writeAll($stream, pack('N', strlen($chunk)) . $chunk);
			}
			fclose($input);
			$this->writeAll($stream, pack('N', 0));

			$response = '';
			while (!feof($stream))
			{
				$part = fread($stream, 4096);
				if ($part === false)
				{
					throw new \RuntimeException('Could not read clamd response.');
				}
				$response .= $part;
				if (strpos($response, "\0") !== false || strpos($response, "\n") !== false)
				{
					break;
				}
			}
			$response = trim($response);
			if (preg_match('/^stream: (.+) FOUND$/D', $response, $matches))
			{
				return ['infected' => true, 'detection' => substr($matches[1], 0, 255)];
			}
			if ($response === 'stream: OK')
			{
				return ['infected' => false, 'detection' => null];
			}

			throw new \RuntimeException('Unexpected clamd response: ' . substr($response, 0, 200));
		}
		finally
		{
			fclose($stream);
		}
	}

	public function shouldScan(\XF\Entity\Attachment $attachment)
	{
		if (!$attachment->Data)
		{
			return true;
		}

		$extension = strtolower($attachment->Data->extension);
		$excludedExtensions = isset($this->config['excluded_extensions']) && is_array($this->config['excluded_extensions'])
			? array_map('strtolower', $this->config['excluded_extensions'])
			: [];
		if ($extension && in_array($extension, $excludedExtensions, true))
		{
			return false;
		}

		if ($attachment->content_type === 'conversation_message' && isset($this->config['scan_private_conversations'])
			&& !$this->config['scan_private_conversations'])
		{
			return false;
		}

		$excludedGroups = isset($this->config['excluded_user_groups']) && is_array($this->config['excluded_user_groups'])
			? array_map('intval', $this->config['excluded_user_groups'])
			: [];
		if ($excludedGroups)
		{
			$user = $attachment->Data->User;
			if ($user)
			{
				$secondaryGroups = is_array($user->secondary_group_ids) ? $user->secondary_group_ids : [];
				$userGroups = array_merge([$user->user_group_id], $secondaryGroups);
				if (array_intersect($excludedGroups, array_map('intval', $userGroups)))
				{
					return false;
				}
			}
		}

		$excludedForums = array_map('intval', $this->parseList($this->config['excluded_forums'] ?? []));
		if ($excludedForums)
		{
			$forumId = $this->getAttachmentForumId($attachment);
			if ($forumId && in_array($forumId, $excludedForums, true))
			{
				return false;
			}
		}

		return true;
	}

	protected function getAttachmentForumId(\XF\Entity\Attachment $attachment)
	{
		if ($attachment->content_type === 'thread')
		{
			$thread = $this->app->em()->find('XF:Thread', $attachment->content_id);
			return $thread ? (int)$thread->node_id : 0;
		}

		if ($attachment->content_type === 'post')
		{
			$post = $this->app->em()->find('XF:Post', $attachment->content_id);
			return $post && $post->Thread ? (int)$post->Thread->node_id : 0;
		}

		return 0;
	}

	public function getPublicContentUrl($contentType, $contentId)
	{
		$content = null;
		if ($contentType === 'post')
		{
			$content = $this->app->em()->find('XF:Post', (int)$contentId);
		}
		else if ($contentType === 'thread')
		{
			$content = $this->app->em()->find('XF:Thread', (int)$contentId);
		}

		return $content ? $content->getContentUrl(true) : null;
	}

	public function sendInfectionAlerts(\XF\Entity\Attachment $attachment, $detection)
	{
		$userIds = isset($this->config['alert_user_ids']) && is_array($this->config['alert_user_ids'])
			? array_unique(array_map('intval', $this->config['alert_user_ids']))
			: [];
		if (!$userIds)
		{
			return;
		}

		$data = $attachment->Data;
		$contentUrl = $this->getPublicContentUrl($attachment->content_type, $attachment->content_id);
		foreach ($userIds AS $userId)
		{
			$user = $this->app->em()->find('XF:User', $userId);
			if (!$user || !$user->email)
			{
				continue;
			}

			try
			{
				$mail = $this->app->mailer()->newMail()->setToUser($user);
				$mail->setTemplate('ltspicer_clamav_infection', [
					'attachmentId' => $attachment->attachment_id,
					'filename' => $data ? $data->filename : '',
					'detection' => $detection,
					'contentUrl' => $contentUrl
				]);
				$mail->send();
			}
			catch (\Throwable $e)
			{
				$this->app->logException($e, false, 'ClamAV infection alert failed: ');
			}
		}
	}

	protected function writeAll($stream, $data)
	{
		$offset = 0;
		$length = strlen($data);
		while ($offset < $length)
		{
			$written = fwrite($stream, substr($data, $offset));
			if ($written === false || $written === 0)
			{
				throw new \RuntimeException('Could not send attachment data to clamd.');
			}
			$offset += $written;
		}
	}
}
