<?php

namespace LTspicer\ClamAVScanner\XF\Admin\Controller;

use XF\Mvc\ParameterBag;

class Attachment extends \XF\Admin\Controller\Attachment
{
	public function actionDelete(ParameterBag $params)
	{
		$returnToScanReport = $this->filter('ltspicer_clamav_return', 'bool');
		$state = $this->filter('ltspicer_clamav_state', 'str');

		$reply = parent::actionDelete($params);

		if ($returnToScanReport && $this->isPost() && !$this->request->exists('delete_attachments'))
		{
			$linkParams = [];
			if (in_array($state, ['pending', 'clean', 'infected', 'error', 'excluded', 'released', 'blocked'], true))
			{
				$linkParams['state'] = $state;
			}

			return $this->redirect($this->buildLink('ltspicer-clamav', null, $linkParams));
		}

		return $reply;
	}
}
