<?php

namespace LTspicer\ClamAVScanner\XF\Entity;

class AttachmentData extends XFCP_AttachmentData
{
	public function getPublicUrl(bool $canonical = false)
	{
		$blocked = $this->db()->fetchOne(
			'
				SELECT COUNT(*)
				FROM xf_attachment AS a
				INNER JOIN xf_ltspicer_clamav_scan AS s ON (s.attachment_id = a.attachment_id)
				WHERE a.data_id = ? AND s.scan_state NOT IN (?, ?, ?)
			',
			[$this->data_id, 'clean', 'excluded', 'released']
		);

		if ($blocked)
		{
			return null;
		}

		return parent::getPublicUrl($canonical);
	}
}
