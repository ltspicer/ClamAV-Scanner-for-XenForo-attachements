<?php

namespace LTspicer\ClamAVScanner\XF\ControllerPlugin;

class Attachment extends XFCP_Attachment
{
	public function displayAttachment(\XF\Entity\Attachment $attachment, $allowViewLog = true)
	{
		if (!$attachment->isScanAllowed())
		{
			return $this->error(\XF::phrase('ltspicer_clamav_attachment_unavailable'));
		}

		return parent::displayAttachment($attachment, $allowViewLog);
	}
}
