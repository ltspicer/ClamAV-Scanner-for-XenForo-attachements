<?php

namespace LTspicer\ClamAVScanner\Job;

use XF\Job\AbstractJob;

class ScanAttachment extends AbstractJob
{
	protected $defaultData = ['attachment_id' => 0];

	public function run($maxRunTime)
	{
		$id = (int)$this->data['attachment_id'];
		$attachment = $this->app->em()->find('XF:Attachment', $id);
		$state = $this->app->db()->fetchOne(
			'SELECT scan_state FROM xf_ltspicer_clamav_scan WHERE attachment_id = ?',
			$id
		);
		if ($state !== 'pending' || ($attachment && $attachment->unassociated))
		{
			return $this->complete();
		}

		if (!$attachment || !$attachment->Data)
		{
			$this->app->db()->update('xf_ltspicer_clamav_scan', [
				'scan_state' => 'error',
				'error_message' => 'Attachment data is missing.'
			], 'attachment_id = ?', $id);
			return $this->complete();
		}

		try
		{
			$tempFile = \XF\Util\File::copyAbstractedPathToTempFile($attachment->Data->getAbstractedDataPath());
			$result = \XF::app()->service(\LTspicer\ClamAVScanner\Service\ClamAv::class)->scanFile($tempFile);

			$this->app->db()->update('xf_ltspicer_clamav_scan', [
				'scan_state' => $result['infected'] ? 'infected' : 'clean',
				'scan_date' => time(),
				'detection' => $result['detection'],
				'error_message' => null
			], 'attachment_id = ?', $id);
			if ($result['infected'])
			{
				\XF::app()->service(\LTspicer\ClamAVScanner\Service\ClamAv::class)
					->sendInfectionAlerts($attachment, $result['detection']);
			}
		}
		catch (\Throwable $e)
		{
			$this->app->db()->update('xf_ltspicer_clamav_scan', [
				'scan_state' => 'error',
				'scan_date' => time(),
				'error_message' => substr($e->getMessage(), 0, 255)
			], 'attachment_id = ?', $id);
			$this->app->logException($e, false, 'ClamAV attachment scan failed: ');
		}

		return $this->complete();
	}

	public function getStatusMessage()
	{
		return 'Scanning attachment #' . (int)$this->data['attachment_id'] . ' with ClamAV';
	}

	public function canCancel()
	{
		return true;
	}

	public function canTriggerByChoice()
	{
		return false;
	}
}
