<?php

namespace LTspicer\ClamAVScanner\Pub\Controller;

class Report extends \XF\Pub\Controller\AbstractController
{
	public function actionIndex()
	{
		$visitor = \XF::visitor();
		if (!$visitor->user_id || !$visitor->hasPermission('general', 'viewClamAvScanReport'))
		{
			return $this->noPermission();
		}

		$scans = $this->app()->db()->fetchAll(
			'
				SELECT s.*, a.data_id, d.filename, d.file_size, d.upload_date
				FROM xf_ltspicer_clamav_scan AS s
				INNER JOIN xf_attachment AS a ON (a.attachment_id = s.attachment_id)
				INNER JOIN xf_attachment_data AS d ON (d.data_id = a.data_id)
				WHERE d.user_id = ?
				ORDER BY d.upload_date DESC, s.attachment_id DESC
				LIMIT 200
			',
			[$visitor->user_id]
		);

		return $this->view('', 'ltspicer_clamav_account_report', [
			'scans' => $scans,
			'pageSelected' => 'clamav_scan_report'
		]);
	}
}
