<?php

namespace LTspicer\ClamAVScanner\XF\ControllerPlugin;

class AttachmentPlugin extends XFCP_AttachmentPlugin
{
	public function displayAttachment(\XF\Entity\Attachment $attachment, $allowViewLog = true)
	{
		if (!$attachment->isScanAllowed())
		{
			return $this->error(\XF::phrase('ltspicer_clamav_attachment_unavailable'));
		}

		return parent::displayAttachment($attachment, $allowViewLog);
	}
}
