<?php

namespace LTspicer\ClamAVScanner;

use XF\AddOn\AbstractSetup;
use XF\Db\Schema\Alter;
use XF\Db\Schema\Create;

class Setup extends AbstractSetup
{
	public function install(array $stepParams = [])
	{
		$this->createScanTable();
	}

	public function upgrade(array $stepParams = [])
	{
		$app = \XF::app();
		$db = $app->db();
		$sm = $this->schemaManager();

		if (!$sm->tableExists('xf_ltspicer_clamav_scan'))
		{
			$this->createScanTable();
		}

		$sm->alterTable('xf_ltspicer_clamav_scan', function (Alter $table)
		{
			$table->changeColumn('scan_state', 'enum')->values(['pending', 'clean', 'infected', 'error', 'excluded', 'released', 'blocked'])->setDefault('pending');
		});

		$scanner = $app->service(\LTspicer\ClamAVScanner\Service\ClamAv::class);
		$pendingIds = $db->fetchAllColumn(
			' SELECT attachment_id FROM xf_ltspicer_clamav_scan WHERE scan_state = ?',
			'pending'
		);

		foreach ($pendingIds AS $attachmentId)
		{
			$attachment = $app->em()->find('XF:Attachment', $attachmentId);
			if (!$attachment)
			{
				$db->delete('xf_ltspicer_clamav_scan', 'attachment_id = ?', $attachmentId);
				continue;
			}

			if ($attachment->unassociated)
			{
				continue;
			}

			if (!$scanner->shouldScan($attachment))
			{
				$db->update('xf_ltspicer_clamav_scan', [
					'scan_state' => 'excluded',
					'scan_date' => time(),
					'detection' => null,
					'error_message' => null
				], 'attachment_id = ?', $attachmentId);
				continue;
			}

			$app->jobManager()->enqueueUnique(
				'ltspicerClamAvScan' . $attachmentId,
				\LTspicer\ClamAVScanner\Job\ScanAttachment::class,
				['attachment_id' => $attachmentId],
				false
			);
		}
	}

	protected function createScanTable()
	{
		$this->schemaManager()->createTable('xf_ltspicer_clamav_scan', function (Create $table)
		{
			$table->addColumn('attachment_id', 'int')->unsigned();
			$table->addColumn('scan_state', 'enum')->values(['pending', 'clean', 'infected', 'error', 'excluded', 'released', 'blocked'])->setDefault('pending');
			$table->addColumn('scan_date', 'int')->unsigned()->setDefault(0);
			$table->addColumn('detection', 'varchar', 255)->nullable();
			$table->addColumn('error_message', 'varchar', 255)->nullable();
			$table->addPrimaryKey('attachment_id');
		});
	}

	public function uninstall(array $stepParams = [])
	{
		$this->schemaManager()->dropTable('xf_ltspicer_clamav_scan');
	}
}
