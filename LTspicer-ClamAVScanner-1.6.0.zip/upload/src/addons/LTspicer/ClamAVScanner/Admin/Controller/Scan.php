<?php

namespace LTspicer\ClamAVScanner\Admin\Controller;

use XF\Mvc\ParameterBag;

class Scan extends \XF\Admin\Controller\AbstractController
{
	protected function preDispatchController($action, ParameterBag $params)
	{
		$this->assertAdminPermission('attachment');
	}

	public function actionIndex()
	{
		$state = $this->filter('state', 'str');
		$allowed = ['pending', 'clean', 'infected', 'error', 'excluded', 'released', 'blocked'];
		$conditions = [];
		$values = [];
		if (in_array($state, $allowed, true))
		{
			$conditions[] = 's.scan_state = ?';
			$values[] = $state;
		}

		$sql = '
			SELECT s.*, a.data_id, d.filename, d.file_size
			FROM xf_ltspicer_clamav_scan AS s
			INNER JOIN xf_attachment AS a ON (a.attachment_id = s.attachment_id)
			INNER JOIN xf_attachment_data AS d ON (d.data_id = a.data_id)
		';
		if ($conditions)
		{
			$sql .= ' WHERE ' . implode(' AND ', $conditions);
		}
		$sql .= ' ORDER BY s.scan_date DESC, s.attachment_id DESC LIMIT 200';

		$scans = $this->app()->db()->fetchAll($sql, $values);
		$cleanCount = (int)$this->app()->db()->fetchOne(
			"SELECT COUNT(*) FROM xf_ltspicer_clamav_scan WHERE scan_state = 'clean'"
		);
		$errorCount = (int)$this->app()->db()->fetchOne(
			"SELECT COUNT(*) FROM xf_ltspicer_clamav_scan AS s
			 INNER JOIN xf_attachment AS a ON (a.attachment_id = s.attachment_id)
			 INNER JOIN xf_attachment_data AS d ON (d.data_id = a.data_id)
			 WHERE s.scan_state = 'error' AND a.unassociated = 0"
		);
		return $this->view('', 'ltspicer_clamav_scan_index', [
			'scans' => $scans,
			'selectedState' => $state,
			'cleanCount' => $cleanCount,
			'errorCount' => $errorCount
		]);
	}

	public function actionRetry(ParameterBag $params)
	{
		$this->assertPostOnly();
		$id = (int)$params->attachment_id;
		$attachment = $this->app()->em()->find('XF:Attachment', $id);
		$exists = $this->app()->db()->fetchOne(
			'SELECT attachment_id FROM xf_ltspicer_clamav_scan WHERE attachment_id = ?',
			$id
		);
		if (!$exists || !$attachment || !$attachment->Data || $attachment->unassociated)
		{
			return $this->notFound();
		}

		$this->app()->db()->update('xf_ltspicer_clamav_scan', [
			'scan_state' => 'pending',
			'scan_date' => 0,
			'detection' => null,
			'error_message' => null
		], 'attachment_id = ?', $id);

		$this->app()->jobManager()->enqueueUnique(
			'ltspicerClamAvScan' . $id,
			\LTspicer\ClamAVScanner\Job\ScanAttachment::class,
			['attachment_id' => $id],
			false
		);

		return $this->redirect($this->buildLink('ltspicer-clamav'), \XF::phrase('ltspicer_clamav_retry_queued'));
	}

	public function actionRetryAll()
	{
		$this->assertAdminPermission('attachment');
		$errorCount = (int)$this->app()->db()->fetchOne(
			"SELECT COUNT(*) FROM xf_ltspicer_clamav_scan AS s
			 INNER JOIN xf_attachment AS a ON (a.attachment_id = s.attachment_id)
			 INNER JOIN xf_attachment_data AS d ON (d.data_id = a.data_id)
			 WHERE s.scan_state = 'error' AND a.unassociated = 0"
		);
		if (!$errorCount)
		{
			return $this->redirect($this->buildLink('ltspicer-clamav'));
		}

		return $this->view('', 'ltspicer_clamav_retry_all_confirm', [
			'errorCount' => $errorCount
		]);
	}

	public function actionRetryAllConfirm()
	{
		$this->assertPostOnly();
		$this->assertAdminPermission('attachment');
		$ids = $this->app()->db()->fetchAllColumn(
			"SELECT s.attachment_id FROM xf_ltspicer_clamav_scan AS s
			 INNER JOIN xf_attachment AS a ON (a.attachment_id = s.attachment_id)
			 INNER JOIN xf_attachment_data AS d ON (d.data_id = a.data_id)
			 WHERE s.scan_state = 'error' AND a.unassociated = 0"
		);
		$queued = 0;
		foreach ($ids AS $id)
		{
			$id = (int)$id;
			$updated = $this->app()->db()->update(
				'xf_ltspicer_clamav_scan',
				[
					'scan_state' => 'pending',
					'scan_date' => 0,
					'detection' => null,
					'error_message' => null
				],
				'attachment_id = ? AND scan_state = ?',
				[$id, 'error']
			);
			if ($updated)
			{
				$this->app()->jobManager()->enqueueUnique(
					'ltspicerClamAvScan' . $id,
					\LTspicer\ClamAVScanner\Job\ScanAttachment::class,
					['attachment_id' => $id],
					false
				);
				$queued++;
			}
		}

		return $this->redirect($this->buildLink('ltspicer-clamav'), \XF::phrase('ltspicer_clamav_retry_all_queued', ['count' => $queued]));
	}

	public function actionForgetAll()
	{
		$this->assertAdminPermission('attachment');
		$cleanCount = (int)$this->app()->db()->fetchOne(
			"SELECT COUNT(*) FROM xf_ltspicer_clamav_scan WHERE scan_state = 'clean'"
		);
		if (!$cleanCount)
		{
			return $this->redirect($this->buildLink('ltspicer-clamav'));
		}

		return $this->view('', 'ltspicer_clamav_forget_all_confirm', [
			'cleanCount' => $cleanCount
		]);
	}

	public function actionForgetAllConfirm()
	{
		$this->assertPostOnly();
		$this->assertAdminPermission('attachment');
		$this->app()->db()->delete(
			'xf_ltspicer_clamav_scan',
			'scan_state = ?',
			'clean'
		);

		return $this->redirect($this->buildLink('ltspicer-clamav'), \XF::phrase('ltspicer_clamav_all_clean_removed'));
	}

	public function actionForget(ParameterBag $params)
	{
		$this->assertPostOnly();
		$id = (int)$params->attachment_id;
		$state = $this->app()->db()->fetchOne(
			'SELECT scan_state FROM xf_ltspicer_clamav_scan WHERE attachment_id = ?',
			$id
		);
		if ($state !== 'clean')
		{
			return $this->notFound();
		}

		$this->app()->db()->delete(
			'xf_ltspicer_clamav_scan',
			'attachment_id = ? AND scan_state = ?',
			[$id, 'clean']
		);

		return $this->redirect($this->buildLink('ltspicer-clamav'), \XF::phrase('ltspicer_clamav_report_entry_removed'));
	}

	public function actionRelease(ParameterBag $params)
	{
		$this->assertPostOnly();
		$id = (int)$params->attachment_id;
		$attachment = $this->app()->em()->find('XF:Attachment', $id);
		$state = $this->app()->db()->fetchOne(
			'SELECT scan_state FROM xf_ltspicer_clamav_scan WHERE attachment_id = ?',
			$id
		);
		if (!$attachment || !$attachment->Data || !in_array($state, ['infected', 'blocked'], true))
		{
			return $this->notFound();
		}

		$this->app()->db()->update('xf_ltspicer_clamav_scan', [
			'scan_state' => 'released',
			'scan_date' => time(),
			'detection' => 'Manually released by ' . \XF::visitor()->username,
			'error_message' => null
		], 'attachment_id = ?', $id);

		return $this->redirect($this->buildLink('ltspicer-clamav'), \XF::phrase('ltspicer_clamav_released'));
	}

	public function actionBlock(ParameterBag $params)
	{
		$this->assertPostOnly();
		$id = (int)$params->attachment_id;
		$attachment = $this->app()->em()->find('XF:Attachment', $id);
		$state = $this->app()->db()->fetchOne(
			'SELECT scan_state FROM xf_ltspicer_clamav_scan WHERE attachment_id = ?',
			$id
		);
		if (!$attachment || !$attachment->Data || $attachment->unassociated || $state !== 'clean')
		{
			return $this->notFound();
		}

		$this->app()->db()->update('xf_ltspicer_clamav_scan', [
			'scan_state' => 'blocked',
			'scan_date' => time(),
			'detection' => 'Manually blocked by ' . \XF::visitor()->username,
			'error_message' => null
		], 'attachment_id = ?', $id);

		return $this->redirect($this->buildLink('ltspicer-clamav'), \XF::phrase('ltspicer_clamav_blocked'));
	}

	public function actionReblock(ParameterBag $params)
	{
		$this->assertPostOnly();
		$id = (int)$params->attachment_id;
		$state = $this->app()->db()->fetchOne(
			'SELECT scan_state FROM xf_ltspicer_clamav_scan WHERE attachment_id = ?',
			$id
		);
		if ($state !== 'released')
		{
			return $this->notFound();
		}

		$this->app()->db()->update('xf_ltspicer_clamav_scan', [
			'scan_state' => 'blocked',
			'scan_date' => time(),
			'detection' => 'Manually blocked by ' . \XF::visitor()->username,
			'error_message' => null
		], 'attachment_id = ?', $id);

		return $this->redirect($this->buildLink('ltspicer-clamav'), \XF::phrase('ltspicer_clamav_reblocked'));
	}
}
