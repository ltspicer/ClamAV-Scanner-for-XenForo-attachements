<?php

namespace LTspicer\ClamAVScanner\XF\Entity;

class Attachment extends XFCP_Attachment
{
	protected $clamAvScanState = null;

	public function getClamAvScanState()
	{
		if ($this->clamAvScanState === null)
		{
			$this->clamAvScanState = $this->db()->fetchOne(
				'SELECT scan_state FROM xf_ltspicer_clamav_scan WHERE attachment_id = ?',
				$this->attachment_id
			);
		}

		return $this->clamAvScanState;
	}

	protected function _postSave()
	{
		parent::_postSave();

		if ($this->isInsert())
		{
			$scanner = $this->app()->service(\LTspicer\ClamAVScanner\Service\ClamAv::class);
			$shouldScan = !$this->unassociated && $scanner->shouldScan($this);
			$this->db()->insert('xf_ltspicer_clamav_scan', [
				'attachment_id' => $this->attachment_id,
				'scan_state' => $this->unassociated || $shouldScan ? 'pending' : 'excluded',
				'scan_date' => 0
			], false, 'attachment_id = VALUES(attachment_id)');

			if ($shouldScan)
			{
				$this->app()->jobManager()->enqueueUnique(
					'ltspicerClamAvScan' . $this->attachment_id,
					\LTspicer\ClamAVScanner\Job\ScanAttachment::class,
					['attachment_id' => $this->attachment_id],
					false
				);
			}
		}
		else if ($this->isUpdate()
			&& ($this->isChanged('content_id') || $this->isChanged('unassociated'))
			&& $this->content_id && !$this->unassociated)
		{
			$scanner = $this->app()->service(\LTspicer\ClamAVScanner\Service\ClamAv::class);
			$shouldScan = $scanner->shouldScan($this);
			$this->db()->update('xf_ltspicer_clamav_scan', [
				'scan_state' => $shouldScan ? 'pending' : 'excluded',
				'scan_date' => 0,
				'detection' => null,
				'error_message' => null
			], 'attachment_id = ?', $this->attachment_id);

			if ($shouldScan)
			{
				$this->app()->jobManager()->enqueueUnique(
					'ltspicerClamAvScan' . $this->attachment_id,
					\LTspicer\ClamAVScanner\Job\ScanAttachment::class,
					['attachment_id' => $this->attachment_id],
					false
				);
			}
		}
	}

	protected function _postDelete()
	{
		parent::_postDelete();
		$this->db()->delete('xf_ltspicer_clamav_scan', 'attachment_id = ?', $this->attachment_id);
	}

	public function canView(&$error = null)
	{
		if (!parent::canView($error))
		{
			return false;
		}

		if (!$this->isScanAllowed())
		{
			$error = \XF::phrase('ltspicer_clamav_attachment_unavailable');
			return false;
		}

		return true;
	}

	public function isScanAllowed()
	{
		// Unassociated uploads are only served through XenForo's temporary-hash
		// attachment route. Let the uploader preview them before they are attached;
		// getPublicUrl() still keeps the public data URL unavailable until scanning.
		if ($this->unassociated && $this->temp_hash)
		{
			return true;
		}

		$state = $this->db()->fetchOne(
			'SELECT scan_state FROM xf_ltspicer_clamav_scan WHERE attachment_id = ?',
			$this->attachment_id
		);

		return $state === false || $state === 'clean' || $state === 'excluded' || $state === 'released';
	}
}
